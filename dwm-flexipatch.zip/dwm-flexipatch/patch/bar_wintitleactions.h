static void hide(Client *c);
static void show(Client *c);
static void togglewin(const Arg *arg);
static Client * prevtiled(Client *c);
static void showhideclient(const Arg *arg);

