static int width_wintitle(Bar *bar, BarArg *a);
static int draw_wintitle(Bar *bar, BarArg *a);
static int click_wintitle(Bar *bar, Arg *arg, BarArg *a);

