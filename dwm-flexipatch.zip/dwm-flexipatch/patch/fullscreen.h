static void fullscreen(const Arg *arg);

