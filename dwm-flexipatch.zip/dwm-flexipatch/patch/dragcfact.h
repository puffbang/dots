static void dragcfact(const Arg *arg);

